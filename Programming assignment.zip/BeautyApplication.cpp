#include <iostream>
#include <vector>
#include <iomanip>
#include <cmath>
#include <string>
#include <cctype> //to use ispunct()
#include <cstdlib> //to use rand() and system()
#include <time.h> //used to get current time to seed the rand function
#include <conio.h> //to use getch function
#include <windows.h> //for cls
#include <fstream>  //to read and write to files
#include <algorithm> //to use the erase() to remove spaces from string

using namespace std;
//initializing the color handler for the console
HANDLE color=GetStdHandle(STD_OUTPUT_HANDLE);


//----------------------------GLOBAL VARIABLES--------------------------------------------------//
//log in status of the application
bool logged_in = false;
string logged_in_user = "";
//schedule for week 1-4
string schedule1[5][3][2];
string schedule2[5][3][2];
string schedule3[5][3][2];
string schedule4[5][3][2];
string booking1[5][3][6];
string booking2[5][3][6];
string booking3[5][3][6];
string booking4[5][3][6];
string appointments[100][8];
string bkkNumber[100];

enum Prices{
    HAIR = 129,
    NAIL = 80,
    WRAP = 269,
    CONSULT = 50
};

//credentials of admin {username, password};
string adminList[3][2] = {
    {"adam", "admin"},
    {"britney", "admin"},
    {"catherine", "admin"}
};
int adminList_size = sizeof(adminList)/(sizeof(adminList[0][0])*2);

//array of experts and their experiences
string experts[3][2] = {
    {"Adam", "With over 10 years of experience in Hair Styling, Adam is known for his innovative cuts and personalized styles that bring out the best in each client. His expertise in creating looks that complement individual features has made him a favorite among clients seeking a fresh, modern appearance."},
    {"Britney", "As our Nail Art and Design expert, Britney brings 8 years of experience and a creative touch to every manicure. Her attention to detail and ability to craft unique, intricate designs make her the go-to for clients who want their nails to stand out."},
    {"Catherine", "Catherine, with 12 years of experience, specializes in Body Wrap treatments. Her deep knowledge of rejuvenating and detoxifying techniques ensures that every session leaves clients feeling relaxed, refreshed, and revitalized."}
};
int experts_size = sizeof(experts)/(sizeof(experts[0][0])*2);

//array of services provided and description
string services[3][2] = {
    {"Hair Styling", "This service involves cutting, coloring, and styling hair to create a desired look. Our expert stylists use the latest techniques and trends to craft personalized styles that enhance your natural beauty, whether it's a chic haircut, a vibrant color, or an elegant updo."},
    {"Nail Design", "Our nail design service offers a wide range of options, from classic manicures and pedicures to intricate nail art. We use high-quality products and tools to ensure your nails are not only beautiful but also healthy and strong."},
    {"Body Wrap", "This service is designed to detoxify, hydrate, and rejuvenate your skin. We use specialized wraps infused with natural ingredients that promote relaxation, reduce cellulite, and leave your skin feeling smooth and refreshed."}
};
//-------------------------------------------------------------------------------------------------//

//--------------functions prototyping-----------------
void logo();
void cls();
void exit_page();
int mainmenu();
void readSchedule();
void readBooking();
void bbsort(string nums[][8], int n);
void readAppointment();
void aboutus_page();
void expertdesc(int);
bool validateEmail(string);
bool cfmBooking(string, string, string, string, int, int, string, double);
bool creditcard(double);
bool onlinetransfer(double);
bool touchngo(double,string);
bool paymentpage(double, string);
void logBooking(string, string, string, int,string, int, string, string, string, string);
string genBKKno(char);
void showAvailableDates(string, int, string);
void bookService(int, int, string);
void servicesdesc(int);
void c_viewServices();
void c_viewExperts();
void c_viewAppointment();
void customer_page();
void showTreatmentSch(string);
void showConsultationSch(string);
void showOverallSch();
void showSalesReport(string);
void staffLogin();
void staff_page();

class Table{
public:
    vector<string> headers;
    //store rows of content
    vector<vector<string>> total_content;


    //a function to store a row of content into the total_content vector
    void add_content(vector<string> content){
        total_content.push_back(content);
    }

    //a function to draw the tables
    void tabulate(){
        //determine the number of columns
        int columns = headers.size();
        int column_widths[columns] = {0};
        int column_widths_adjusted[columns];

        //determining the widths of each columns
        //iterating through headers
        for(int i=0; i<columns; i++){
            column_widths[i] = headers[i].size() > column_widths[i]? headers[i].size() : column_widths[i];
        }
        //iterating each row of content
        for(auto x : total_content){

            //accessing each columns of the row and finding the biggest width of each column
            for(int i=0; i<columns; i++){
                column_widths[i] = x[i].size()>column_widths[i]? x[i].size() : column_widths[i];
            }
        }
        
        //add more widths to each columns to support spacing
        for(int i=0; i<columns; i++){
            column_widths_adjusted[i] = column_widths[i]+8;
        }

        //printing the top border of the header
        cout << "\t" <<'+';
        for(auto x : column_widths_adjusted){
            for(int i=0; i<x-2; i++){
                cout << '=';
            }
            cout << '+';
        }
        cout << endl;

        //printing the headers
        cout << "\t" << '|';
        for(int i=0; i<headers.size(); i++){
            cout << left << setw(2) <<' ';
            SetConsoleTextAttribute(color, 11);
            cout << headers[i] << right << setw(column_widths_adjusted[i]-headers[i].size()-3);
            SetConsoleTextAttribute(color, 15);
            cout << '|';
        }
        cout << endl;

        //printing the bottom border of the header
        cout << "\t" <<'+';
        for(auto x : column_widths_adjusted){
            for(int i=0; i<x-2; i++){
                cout << '=';
            }
            cout << '+';
        }
        cout << endl;

        //printing each row of content
        for(int x=0; x<total_content.size(); x++){
            cout << x+1 << ".      |";

            //printing the content of each column of each row
            for(int z=0; z<columns; z++){
                cout << left << setw(2) <<' ';
                cout << total_content[x][z] << right <<setw(column_widths_adjusted[z]-total_content[x][z].size()-3) << '|';
            }
            cout << endl;

            //after finish printing each row print border
            cout << "\t" <<'+';
            for(auto x : column_widths_adjusted){
                for(int i=0; i<x-2; i++){
                    cout << '-';
                }
                cout << '+';
            }
            cout << endl;
            
    
        }
    }
};


int main(){
    bool exit = false;
    readSchedule(); readBooking();  readAppointment(); bbsort(appointments, 100);

    //adding confirmed booking number to the bkk number array
    for(int i=0; i<100; i++){
        if(appointments[i][0]!=""){
            bkkNumber[i] = appointments[i][0];
        }
    }

    while(!exit){
        switch(mainmenu()){
            case 1:
                aboutus_page();
                break;
            case 2:
                customer_page();
                break;
            case 3:
                staff_page();
                break;
            case 4:
                exit = true;
        }     
    }

    exit_page();
    return 0;
}


void logo(){
    string logo = R"(
 ___  _   _  ___  ___    ___  ___    _    _   _  _____ __   __
| _ \| | | || _ \| __|  | _ )| __|  /_\  | | | ||_   _|\ \ / / 
|  _/| |_| ||   /| _|   | _ \| _|  / _ \ | |_| |  | |   \ V /  
|_|   \___/ |_|_\|___|  |___/|___|/_/ \_\ \___/   |_|    |_|   
                                                                
    )";
    SetConsoleTextAttribute(color, 5);
    cout<< logo << endl;
    SetConsoleTextAttribute(color, 15);
}


void cls(){
    system("cls");
}


void exit_page(){
    cls();
    string exit = R"(
            
 _____ _                 _      __   __          _ 
|_   _| |               | |     \ \ / /         | |
  | | | |__   __ _ _ __ | | __   \ V /___  _   _| |
  | | | '_ \ / _` | '_ \| |/ /    \ // _ \| | | | |
  | | | | | | (_| | | | |   <     | | (_) | |_| |_|
  \_/ |_| |_|\__,_|_| |_|_|\_\    \_/\___/ \__,_(_)
                                                   
                                                
    )";
    cout << exit << endl;
    Sleep(4000);
}


int mainmenu(){
    int choice = 0;
    cls();
    logo();
    Table menu;
    menu.headers = {"Main Menu"};
    menu.add_content({"About US"});
    menu.add_content({"Customer"});
    menu.add_content({"Staff Portal"});
    menu.add_content({"Exit"});
    menu.tabulate();

    //asking for inputs
    while(true){
        cout << "Please Select : ";
        cin >> choice;

        if(cin.fail()){
            //clearing the buffers incase fail
            cin.clear();
            cin.ignore(100,'\n');
            cls();
            logo();
            menu.tabulate();
            SetConsoleTextAttribute(color, 4);
            cout << "Error! Enter Valid Numbers Only." << endl;
            SetConsoleTextAttribute(color, 15);
        }else{
            //if input buffer no error then check if number within valid range
            if(choice < 1 || choice > 4){
                cls();
                logo();
                menu.tabulate();
                SetConsoleTextAttribute(color, 4);
                cout << "Error! Enter Valid Numbers Only." << endl;
                SetConsoleTextAttribute(color, 15);
            }else{
                break;
            }
        }



        
    }
    return choice;
}

void readSchedule(){


    //------------read schedule for week1---------------
    string data;
    int x=0, y=0;
    ifstream ScheduleFile("datas\\week1Sch.txt");
    while(getline(ScheduleFile, data)){
        string dataSplit[2];
        bool secondword = false;
        //cout <<  data << endl;
        for(int i=0; i<data.size(); i++){
            if(!isdigit(data[i])){
                secondword = true;
                continue;
            }
            if(secondword)
                dataSplit[1]+=data[i];
            else
                dataSplit[0]+=data[i];
        }


        if(isdigit(dataSplit[1][0])){
            schedule1[x][y][0] = dataSplit[0];
            schedule1[x][y][1] = dataSplit[1];
            y++;
            if(y==3){
                y=0;
                x++;
            }
        }

    }
    ScheduleFile.close();



    //------------read schedule for week2---------------
    data="";
    x=0, y=0;
    ifstream ScheduleFile2("datas\\week2Sch.txt");
    while(getline(ScheduleFile2, data)){
        string dataSplit[2];
        bool secondword = false;
        //cout <<  data << endl;
        for(int i=0; i<data.size(); i++){
            if(!isdigit(data[i])){
                secondword = true;
                continue;
            }
            if(secondword)
                dataSplit[1]+=data[i];
            else
                dataSplit[0]+=data[i];
        }


        if(isdigit(dataSplit[1][0])){
            //cout << dataSplit[0] << " " << dataSplit[1] << endl;
            schedule2[x][y][0] = dataSplit[0];
            schedule2[x][y][1] = dataSplit[1];
            y++;
            if(y==3){
                y=0;
                x++;
            }
        }

    }
    ScheduleFile2.close();



    //------------read schedule for week3---------------
    data="";
    x=0, y=0;
    ifstream ScheduleFile3("datas\\week3Sch.txt");
    while(getline(ScheduleFile3, data)){
        string dataSplit[2];
        bool secondword = false;
        //cout <<  data << endl;
        for(int i=0; i<data.size(); i++){
            if(!isdigit(data[i])){
                secondword = true;
                continue;
            }
            if(secondword)
                dataSplit[1]+=data[i];
            else
                dataSplit[0]+=data[i];
        }


        if(isdigit(dataSplit[1][0])){
            //cout << dataSplit[0] << " " << dataSplit[1] << endl;
            schedule3[x][y][0] = dataSplit[0];
            schedule3[x][y][1] = dataSplit[1];
            y++;
            if(y==3){
                y=0;
                x++;
            }
        }

    }
    ScheduleFile3.close();




    //------------read schedule for week4---------------
    data="";
    x=0, y=0;
    ifstream ScheduleFile4("datas\\week4Sch.txt");
    while(getline(ScheduleFile4, data)){
        string dataSplit[2];
        bool secondword = false;
        //cout <<  data << endl;
        for(int i=0; i<data.size(); i++){
            if(!isdigit(data[i])){
                secondword = true;
                continue;
            }
            if(secondword)
                dataSplit[1]+=data[i];
            else
                dataSplit[0]+=data[i];
        }


        if(isdigit(dataSplit[1][0])){
            //cout << dataSplit[0] << " " << dataSplit[1] << endl;
            schedule4[x][y][0] = dataSplit[0];
            schedule4[x][y][1] = dataSplit[1];
            y++;
            if(y==3){
                y=0;
                x++;
            }
        }

    }
    ScheduleFile4.close();
}

void readBooking(){
    int x=0, y=0, z=0;
    string data;

    //read for file 1
    x=0, y=0, z=0;
    data = "";
    ifstream ReadBook1("datas\\BKKweek1.txt");


    while(getline(ReadBook1, data)){
       // cout << data << endl;
        //if y is 4 move to next x
        if(y==3){
            y=0;
            x++;
            continue;
        }
        
        //loop through each row
        for(int i=0; i<data.size(); i++){
            if(data[i]==' '){
                z++;
                continue;
            }
            booking1[x][y][z]+=data[i];
            
        }

        //after each row is done
        //move to next row but still in first x
        y++;
        z=0;

    }
    ReadBook1.close();




    //read for file 2
    x=0, y=0, z=0;
    data = "";
    ifstream ReadBook2("datas\\BKKweek2.txt");


    while(getline(ReadBook2, data)){
       // cout << data << endl;
        //if y is 4 move to next x
        if(y==3){
            y=0;
            x++;
            continue;
        }
        
        //loop through each row
        for(int i=0; i<data.size(); i++){
            if(data[i]==' '){
                z++;
                continue;
            }
            booking2[x][y][z]+=data[i];
            
        }

        //after each row is done
        //move to next row but still in first x
        y++;
        z=0;

    }
    ReadBook2.close();






    //read for file 3
    x=0, y=0, z=0;
    data = "";
    ifstream ReadBook3("datas\\BKKweek3.txt");


    while(getline(ReadBook3, data)){
       // cout << data << endl;
        //if y is 4 move to next x
        if(y==3){
            y=0;
            x++;
            continue;
        }
        
        //loop through each row
        for(int i=0; i<data.size(); i++){
            if(data[i]==' '){
                z++;
                continue;
            }
            booking3[x][y][z]+=data[i];
            
        }

        //after each row is done
        //move to next row but still in first x
        y++;
        z=0;

    }
    ReadBook3.close();








    //read for file 4
    x=0, y=0, z=0;
    data = "";
    ifstream ReadBook4("datas\\BKKweek4.txt");


    while(getline(ReadBook4, data)){
       // cout << data << endl;
        //if y is 4 move to next x
        if(y==3){
            y=0;
            x++;
            continue;
        }
        
        //loop through each row
        for(int i=0; i<data.size(); i++){
            if(data[i]==' '){
                z++;
                continue;
            }
            booking4[x][y][z]+=data[i];
            
        }

        //after each row is done
        //move to next row but still in first x
        y++;
        z=0;

    }
    ReadBook4.close();
}

void bbsort(string nums[][8], int n){
    string temp[8];
    for(int i=0; i<n; i++){
        if(nums[i][7] == "")
            break;
        for(int j=i+1; j<n; j++){
            if(nums[j][7] == "")
                break;
            //if first element bigger than second element
            if(stoi(nums[i][7]) > stoi(nums[j][7])){
                for(int x=0; x<8; x++){
                    temp[x] = nums[i][x];
                    nums[i][x] = nums[j][x];
                    nums[j][x] = temp[x];
                }
            }
        }


    }
}

void readAppointment(){
    string line;
    int x=0, y=0;
    ifstream appt("datas\\appointment.txt");
    while(getline(appt, line)){
        for(int i=0; i<line.size(); i++){
            if(line[i] == ' '){
                y++;
                continue;
            }
            appointments[x][y]+=line[i];
        }
        x++;
        y=0;
    }
    appt.close();
}

void aboutus_page(){
    char input;
    cls();
    logo();
    string desc = R"(
    Welcome to Pure Beauty, where elegance meets safety in the realm of aesthetics. 
    With utmost pride, we stand as your premium destination for achieving transformative aesthetic 
    enhancements since 2015, and we have been progressing immensely well throughout the years. 
    
    At Pure Beauty, our commitment to provide beauty procedures is unwavering. 
    With a team of skilled professionals and experienced beauty therapists, 
    we adhere to the highest standards of practice, 
    ensuring that each procedure is carried out with meticulous care and precision. 

    We provide wide range of beauty treatment : 
    Hair Styling
    Nail Art and Design
    Body Wrap
    )";
    cout << desc << endl;
    cout << "\nEnter any key to go back : ";
    input = getch();
    cls();
}

void expertdesc(int x){
    cls();
    logo();
    char input;
    x-=1;
    string expertName = experts[x][0];
    string expertexp = experts[x][1];
    for(char& x:expertName){
        x = toupper(x);
    }
    cout << expertName << endl << endl;

    for(int i=0; i<expertexp.size(); i++){
        if(i%75 == 0){
            cout << endl;
            if(expertexp[i] == ' ')
                continue;
            else if(expertexp[i] == '.'){
                i++;
                continue;
            }
        }
        cout << expertexp[i];
    }
    cout << "\n\n\nEnter any key to go back : ";
    input = getch();
}

bool validateEmail(string email){
    int indexAlias=0, indexDot=0, aliascount=0;
    if(isdigit(email[0]) || ispunct(email[0]))
        return false;
    for(int i=0; i<email.size(); i++){
        if(email[i]=='@'){
            indexAlias = i;
            aliascount++;
        }
        else if(email[i]=='.')
            indexDot = i;
    }
    if(indexAlias==0 || indexDot==0)
        return false;
    if(indexAlias>indexDot)
        return false;
    if(aliascount>1)
        return false;
    if(indexDot == indexAlias+1)
        return false;
    if(email[email.size()-1] == '.' || isdigit(email[email.size()-1]) || ispunct(email[email.size()-1]))
        return false;

    return true;
}

bool cfmBooking(string customerName, string customerEmail, string bookingChoice, string servicename, int service, int date, string day, double price){
    char input='y';
    cls();logo();
    do{
        if(tolower(input)!='y' && tolower(input)!='n'){
            cls();logo();
            SetConsoleTextAttribute(color, 10);
            cout << "BOOKING CONFIRMATION" << endl;
            SetConsoleTextAttribute(color, 15);
            cout << left << setw(15) <<"Name" << " : " << customerName << endl;
            cout << left << setw(15) << "Email" << " : " << customerEmail << endl;
            cout << left << setw(15) << "Booking ID" << " : " << bookingChoice << endl;
            cout << left << setw(15) << "Service" << " : "<< servicename << endl;
            if(service == 1)
                cout << left << setw(15) << "Service Type" << " : " << "Treatment" << endl;
            else
                cout << left << setw(15) << "Service Type" << " : " << "Consultation" << endl;
            cout << left << setw(15) << "Date" << " : " << date << ", " << day << endl;
            cout << left << setw(15) << "Price" << " : RM " << fixed << setprecision(2) << price;
            SetConsoleTextAttribute(color, 4);
            cout << "\n\nInvalid Input!" << endl;
            SetConsoleTextAttribute(color, 15);
            cout << "Proceed to Payment? [y/n] : ";
            cin >> input;
            if(tolower(input)!='y' && tolower(input)!='n')
                continue;
            if(tolower(input) == 'y')
                return true;
            else
                return false;
        }
        SetConsoleTextAttribute(color, 10);
        cout << "BOOKING CONFIRMATION" << endl;
        SetConsoleTextAttribute(color, 15);
        cout << left << setw(15) <<"Name" << " : " << customerName << endl;
        cout << left << setw(15) << "Email" << " : " << customerEmail << endl;
        cout << left << setw(15) << "Booking ID" << " : " << bookingChoice << endl;
        cout << left << setw(15) << "Service" << " : "<< servicename << endl;
        if(service == 1)
            cout << left << setw(15) << "Service Type" << " : " << "Treatment" << endl;
        else
            cout << left << setw(15) << "Service Type" << " : " << "Consultation" << endl;
        cout << left << setw(15) << "Date" << " : " << date << ", " << day << endl;
        cout << left << setw(15) << "Price" << " : RM " << fixed << setprecision(2) << price;

        cout << "\n\nProceed to Payment? [y/n] : ";
        cin >> input;

    }while(tolower(input)!='y' && tolower(input)!='n');

    if(tolower(input) == 'y')
        return true;
    else
        return false;
}

bool creditcard(double price){
    bool answer = false, validcard = false;
    char c;
    string cardnumber="", cardexpire = "", cvv="", cardtype;
    int digit_counter=0, total_digit=0;

    cls();logo();
    cout << "You will be charged << RM " << fixed << setprecision(2) << price << " >> through your card." << endl;
    do{
        cardnumber="";
        digit_counter=0; total_digit=0;
        cout << "Enter your card number : ";
        while((c=getch())!= 13){
            if(c==8){
                if((total_digit-1)%4 == 0 && (total_digit-1)>0)
                    cout << "\b \b";
                if(!cardnumber.empty()){
                    cout << "\b \b";
                    total_digit--;
                    digit_counter--;
                    cardnumber.pop_back();
                    if(digit_counter == 0 && !cardnumber.empty())
                        digit_counter = 4;
                    continue;
                }
                
            }
            else{
                if(total_digit < 16 && isdigit(c)){
                    cout << c;
                    cardnumber+=c;
                    digit_counter++;
                    total_digit++;
                }
                if(digit_counter == 4 && total_digit!=16){
                    cout << " ";
                    digit_counter = 0;
                }
            }
        }
        
        if(cardnumber[0] == '4'){
            cardtype = "VISA";
            validcard = true;
            answer = true;
        }
        else if(cardnumber.substr(0,2) == "51" || cardnumber.substr(0,2) == "52" || 
        cardnumber.substr(0,2) == "53" || cardnumber.substr(0,2) == "54" || cardnumber.substr(0,2) == "55" || 
        cardnumber.substr(0,4) == "2221" || cardnumber.substr(0,4) == "2720"){
            cardtype = "MasterCard";
            validcard = true;
            answer = true;
        }

        if(!validcard){
            cls();logo();
            cout << "You will be charged << RM " << fixed << setprecision(2) << price << " >> through your card." << endl;
            SetConsoleTextAttribute(color, 4);
            cout << "Invalid Card Number!" << endl;
            SetConsoleTextAttribute(color, 15);
        }

    }while(!validcard);
    
    cls();logo();
    cout << "You will be charged << RM " << fixed << setprecision(2) << price << " >> through your card." << endl;
    cout << "Enter your card number : ";
    for(int i=0; i<cardnumber.size(); i++){
        cout << cardnumber[i];
        if((i+1)%4 == 0)
            cout << " ";
    }
    if(cardtype == "VISA"){
        SetConsoleTextAttribute(color, 1);
        cout << " " << cardtype << endl;
        SetConsoleTextAttribute(color, 15);
    }
    else{
        SetConsoleTextAttribute(color, 4);
        cout << " " << cardtype.substr(0,6);
        SetConsoleTextAttribute(color, 6);
        cout << cardtype.substr(6,4) << endl;
        SetConsoleTextAttribute(color, 15);
    }


    cout << "Enter expiry date (mm/yy) : ";
    while((c=getch())!=13){
        if(c == 8){
            if(!cardexpire.empty()){
                if(cardexpire.size() == 2)
                    cout << "\b \b";
                cout << "\b \b";
                cardexpire.pop_back();
            }
            continue;
        }
        if(cardexpire.size() == 0){
            if(c<50 &&  c!=45){
                cout << c;
                cardexpire+=c;
            }
        }
        else if(cardexpire.size() == 1){
            if(cardexpire[0] == '1'){
                if(c<51 &&  c!=45){
                    cout << c << '/';
                    cardexpire+=c;
                }else{;}
            }else{
                cout << c << '/';
                cardexpire+=c;
            }
        }
        else if(cardexpire.size() == 2){
            if(c>=50 && c<=51){
                cout << c;
                cardexpire+=c;
            }
        }else if(cardexpire.size() == 3){
            cout << c;
            cardexpire+=c;
        }
    }
    
    cout << "\nEnter cvv : ";
    while((c=getch())!=13){
        if(c==8){
            if(!cvv.empty()){
                cout << "\b \b";
                cvv.pop_back();
            }
            continue;
        }
        if(cvv.size()<3 && isdigit(c)){
            cout << c;
            cvv+=c;
        }
    }
    
    return answer;
}

bool onlinetransfer(double price){
    string reference_id = "";

    cls();logo();
    cout << "You will be charged << RM " << fixed << setprecision(2) << price << " >> through online transfer." << endl << endl;
    cout << left << setw(25) << "BANK" << " : " << "MAYBANK" << endl;
    cout << left << setw(25) <<"BANK ACCOUNT NAME" << " : " << "PureBeauty SDN BHD" << endl;
    cout << left << setw(25) <<"BANK ACCOUNT NUMBER" << " : " << "1540 8023 1525" << endl;

    cout << "\nPlease enter transaction Reference ID : ";
    cin >> reference_id;
    return reference_id.size();
}

bool touchngo(double price,string bookingid){
    system("chcp 65001");
    cls();logo();
    cout << "You will be charged << RM " << fixed << setprecision(2) << price << " >> through Touch n GO." << endl << endl;

    string qrcode = u8R"(                                                                                                                       
   █▀▀▀▀▀▀██ ▄▀▀▀  ▀▄▄▄▀▀█▀ ▀▀  █▀▀█▀▀█▄ █ ▄▄▄█ ▄▄██ █▀▀▀▀▀▀█   
   █  ███ ██  █ ▀▀██▀▄▀▄ ▀█ ▀   ▀ █▀  ▄  ███▀▀ ▄ █▀▀ █ ████ █   
   █  ▀▀▀ ██ ▄█▀  █▀ ▄█▀ ▄▀▄ █▀▀▀▀█ █████▀▀▀  █ ▄    █ ▀▀▀▀ █   
   █▄▄▄▄▄▄██ █ ▄  █ ▄ █  █ █ █  ▄ █ █▀▀█▀▄ ▄▄ █ █ ▄▄ █▄▄▄▄▄▄█   
        ▄▄▄▄▄▀█▄█▀▀▄▀▄▀  ▄▀  █▄▄▄▄█▀▄  █ █ ███ █ ▄▄▄ ▄▄    ▄    
   ███▀█▄▀▄▄▀█▀   ▄█▀█▄▀▀▀▀█ ▀██▀▀█ ▄ ▀▀█▄▄▄  ▄▄█ ▄▄ ▀ ▀█▄▄ █   
   █████ █    █   ████ ████ ██   █  █  █   █████ █████  ████    
   █  ██▀ ▀▀▀▀▄ ▄ ▀█▀▄█▀ ▄▄█ ▄  █▀▀█  ▄▀▄▄ ▀▀ ▀█▀ ▄▄  ▀█  █▄▀   
   ▄▄▄ ▄█▄▀▀      ▀██▄▀▀▀▀▄▄▄▀██▀▄  ▄▄█  ▄█████  ███ ▄ ▀███▀    
   ██▀▀ ▀ ▀▀▀█  █  █▀ █▀▀█ █  ▀▀▀ ██▀▀▀  █▀  ▀▀ █     ██        
   ▀   ▀▄ ▄▄▄▀ ▄▀  █ ▀█▄ ▀ █  ▄▄▄███▄  ▄▄▀ ▄▄▄▄█▀█▀▀█ ▀▀▄▄▄▄▀   
   ▀▀█ ██ ▄▄▄▄ ▄  ▄█▄▄ ▀▀▄▀██ ▀▀ ▄▀▀  ██▀ ▀▄ ▀██ ▄▄▄▀▀▄▄▀▀▀▀▄   
     █▀ ▄▄▄▄██  █  ▄ ▀ █  ▄▀▄▄▄▄█▄█▀  ▄ ▄▄ ▄▄▄  ▀▄▄▄▄███▄▄▄▄▀   
     █  █▀▀▀▀█  █▄▄▀▄  █▄▄█▄██▀▀▀▀█▄▄ ▀▄▀▀ ██▀  ▄███▀▀▀████▀    
   ▄▄▄▀ █ ▀▀ ███▄▄██      ▀███  ▀ █▄  ▀▀▄ ▀▄ ▀▄▀████ ▀ █▄▄██▀   
     █ ▄██▀▀▀█▄▀▀  ▄▀▀█▀▀█▄▄█▀▀▀▀██ ▄  █▀▀ ▀▀█▀   ▀▀▀█▀█▄ ▀▀▄   
   ███  █ █████ █   █  █████ ███ █ ██   ██    ██     █ █   ██   
   ▀ ▄▀█▀█▄▄█▀ ▀▀▀███  █▄▄   █▀▀ █▀▄  █▄▀▄▄▄▄█▀▀▄ ██ ▀█▀▄   ▀   
   ▄▄▄▀███▄▄▄  ▀▄▄▄  ▀▄▀▀█▄▀▀▄▄▄ █▄▀█  ▀█▄▀▀  ▄▄▄ ██▀█ ▄▄  ▀    
   █   █▀▀    ▀█      ▀█  █ █ ▀▀▀█  ▀▀█  ▀   █▀   ▀▀ ▀      ▀   
   ████▀ ▄▀▀█▀▄█  ██▀█ ███▀▄█▀▄▄▄█▄▄  ▀   ▀███▄▄ █▄▄▀ ▄▄█▀▀     
   ████▄ ▀▀▀▀▀▀█  ▄▄▄█▀▀ ▄ ▀█▀   █▀█  █▀▄█   ▄▀ ▀ ████▀▄▄▄█▀    
     █▄▄ ▀▀▀  ▀█▀▀█▄▀█▄▄▄▄ ▄▄ ███▀▀█  ▄ █▄▀▀ ▄████  █ █ ▀   ▄   
   ▄▄██▀  ▄▄   █  █▀▄█▀▀ █ ▀█▄███▄▄▀  █ ██ ▄▄▀▀█▀█▄▄█▄█▄    ▀   
   ▄▄▄▄▄▄▄▄▄ █▄▀▀ ▄▀█▀▀███▄▀▀█  ▄ █▀▄ ▀ ▀▀██▀▀▀  ▄██ ▄ █   ▄▀   
   █  ▄▄▄ ██ █▄██▄▄▄▀▄██▀▀▀▀ █▄▄▄▄█▀▄  ▀█▄▀▀▀█▄▄▄ ██▄▄▄█▀▀█▀    
   █  ███ ██  █   ████   ███ ███████████████▀ █ ██     ██   █   
   █  ▀▀▀ ██  ▄ ███▀ ▀█  ▄▄▀  ██▄▀▄▄  ▀ ▄▄▀  ▄ ▀█▀██▄  ▄▀ ▄▀    
   ▀▀▀▀▀▀▀▀▀   ▀▀  ▀ ▀ ▀▀▀▀ ▀▀▀▀ ▀    ▀▀  ▀▀▀▀▀▀▀    ▀▀▀▀▀▀ ▀                                                     
    )";


    SetConsoleTextAttribute(color, 4);
    cout << qrcode << endl;
    SetConsoleTextAttribute(color, 15);

    cout << "\nPlease add \"" << bookingid << "\" to your payment details for reference purposes." << endl;
    cout << "Enter any key after transfer completed : ";
    getch();
    system("chcp 437");
    return true;

}

bool paymentpage(double price, string bookingid){
    cls();logo();
    int input;
    bool answer=false;
    string paymentstyle;
    Table paymentmethods;
    paymentmethods.headers = {"Payment Methods"};
    paymentmethods.add_content({"Credit/Debit Card"});
    paymentmethods.add_content({"Online Transfer"});
    paymentmethods.add_content({"Touch n GO"});
    paymentmethods.tabulate();

    while(true){
    cout << "Please Select A Payment Method : ";
    cin >> input;

    if(cin.fail()){
        //clearing the buffers incase fail
        cin.clear();
        cin.ignore(100,'\n');
        cls();
        logo();
        paymentmethods.tabulate();
        SetConsoleTextAttribute(color, 4);
        cout << "Error! Enter Valid Numbers Only." << endl;
        SetConsoleTextAttribute(color, 15);
    }else{
        //if cin buffer no error then check if number within valid range
        if(input < 1 || input > 3){
            cls();
            logo();
            paymentmethods.tabulate();
            SetConsoleTextAttribute(color, 4);
            cout << "Error! Enter Valid Numbers Only." << endl;
            SetConsoleTextAttribute(color, 15);
        }else{
            break;
        }
        }
    }

    switch(input){
        case 1:
            paymentstyle = "Credit/Debit Card";
            answer = creditcard(price);
            break;
        case 2:
            paymentstyle = "Online Transfer";
            answer = onlinetransfer(price);
            break;
        case 3:
            paymentstyle = "Touch n GO";
            answer = touchngo(price,bookingid);
    }

    return answer;
}

void logBooking(string name, string bookingID, string servicename, int week ,string day, int date, string expertName, string email, string servicetype, string price){
    string line = "";
    int x=0, y=0, z=0, hrsUsed=0;

    hrsUsed = bookingID[0] == 'T'? 2 : 1;
    z = bookingID[0] == 'T'? 0 : 1;
    switch(date){
        case 1:
        case 8:
        case 15:
        case 22:
            x = 0;
            break;
        case 2:
        case 9:
        case 16:
        case 23:
            x = 1;
            break;
        case 3:
        case 10:
        case 17:
        case 24:
            x = 2;
            break;
        case 4:
        case 11:
        case 18:
        case 25:
            x = 3;
            break;
        case 5:
        case 12:
        case 19:
        case 26:
            x = 4;
            break;
    }
    switch(expertName[0]){
        case 'A':
            y=0;
            break;
        case 'B':
            y=1;
            break;
        case 'C':
            y=2;
            break;
    }
    
    //updating the arrays in the main function first before writing to file
    switch(week){
        //if week 1 see who is the expert and update hrs and update bkk id
        case 1:
            schedule1[x][y][z] = to_string(stoi(schedule1[x][y][z]) + hrsUsed);
            for(int i=0; i<6; i++){
                if(booking1[x][y][i] == "0"){
                    booking1[x][y][i] = bookingID;
                    i=6;
                }
            }
            break;
        case 2:
            schedule2[x][y][z] = to_string(stoi(schedule2[x][y][z]) + hrsUsed);
            for(int i=0; i<6; i++){
                if(booking2[x][y][i] == "0"){
                    booking2[x][y][i] = bookingID;
                    i=6;
                }
            }
            break;
        case 3:
            schedule3[x][y][z] = to_string(stoi(schedule3[x][y][z]) + hrsUsed);
            for(int i=0; i<6; i++){
                if(booking3[x][y][i] == "0"){
                    booking3[x][y][i] = bookingID;
                    i=6;
                }
            }
            break;
        case 4:
            schedule4[x][y][z] = to_string(stoi(schedule4[x][y][z]) + hrsUsed);
            for(int i=0; i<6; i++){
                if(booking4[x][y][i] == "0"){
                    booking4[x][y][i] = bookingID;
                    i=6;
                }
            }
            break;

    }

    //updating the appointment array to be written back to the file
    //loop through each row of the array and find empty line to insert data
    //remove space in the service name
    servicename.erase(remove(servicename.begin(), servicename.end(), ' '), servicename.end());
    for(int i=0; i<100; i++){
        //if found empty line then write information here
        if(appointments[i][0] == ""){
            appointments[i][0] = bookingID;
            appointments[i][1] = name;
            appointments[i][2] = email;
            appointments[i][3] = servicename;
            appointments[i][4] = servicetype;
            appointments[i][5] = expertName;
            appointments[i][6] = price;
            appointments[i][7] = to_string(date);
            i = 100;
        }

    }


    //logging the bookings in both the booking file and schedule file
    //writing to appointmentfile
    ofstream ApptFile("datas\\appointment.txt");
    for(int i=0; i<100; i++){
        line = "";
        for(int y=0; y<8; y++){
            line+=appointments[i][y];
            if(y!=7)
                line+=" ";
        }
        ApptFile << line << endl;
    }
    ApptFile.close();

    line="";
    //writing to file 1
    ofstream WriteFileSCH1("datas\\week1Sch.txt");
    for(int x=0; x<5; x++){
        for(int y=0; y<3; y++){
            for(int z=0; z<2; z++){
                line+=schedule1[x][y][z];
                if(z!=1)
                    line+=" ";
            }
            WriteFileSCH1 << line << endl;
            line="";
        }
        WriteFileSCH1 << endl;
    }
    WriteFileSCH1.close();
    line="";

    ofstream WriteFileBKK1("datas\\BKKweek1.txt");
    for(int x=0; x<5; x++){
        for(int y=0; y<3; y++){
            for(int z=0; z<6; z++){
                line+=booking1[x][y][z];
                //if last element no need add space
                if(z!=5)
                    line+=" ";
            }
            WriteFileBKK1 << line << endl;
            line="";
        }
        WriteFileBKK1 << endl;
    }
    WriteFileBKK1.close();
    line="";


    //writing to file 2
    ofstream WriteFileSCH2("datas\\week2Sch.txt");
    for(int x=0; x<5; x++){
        for(int y=0; y<3; y++){
            for(int z=0; z<2; z++){
                line+=schedule2[x][y][z];
                if(z!=1)
                    line+=" ";
            }
            WriteFileSCH2 << line << endl;
            line="";
        }
        WriteFileSCH2 << endl;
    }
    WriteFileSCH2.close();
    line="";

    ofstream WriteFileBKK2("datas\\BKKweek2.txt");
    for(int x=0; x<5; x++){
        for(int y=0; y<3; y++){
            for(int z=0; z<6; z++){
                line+=booking2[x][y][z];
                //if last element no need add space
                if(z!=5)
                    line+=" ";
            }
            WriteFileBKK2 << line << endl;
            line="";
        }
        WriteFileBKK2 << endl;
    }
    WriteFileBKK2.close();
    line="";




    //writing to file 3
    ofstream WriteFileSCH3("datas\\week3Sch.txt");
    for(int x=0; x<5; x++){
        for(int y=0; y<3; y++){
            for(int z=0; z<2; z++){
                line+=schedule3[x][y][z];
                if(z!=1)
                    line+=" ";
            }
            WriteFileSCH3 << line << endl;
            line="";
        }
        WriteFileSCH3 << endl;
    }
    WriteFileSCH3.close();
    line="";

    ofstream WriteFileBKK3("datas\\BKKweek3.txt");
    for(int x=0; x<5; x++){
        for(int y=0; y<3; y++){
            for(int z=0; z<6; z++){
                line+=booking3[x][y][z];
                //if last element no need add space
                if(z!=5)
                    line+=" ";
            }
            WriteFileBKK3 << line << endl;
            line="";
        }
        WriteFileBKK3 << endl;
    }
    WriteFileBKK3.close();
    line="";





    //writing to file 4
    ofstream WriteFileSCH4("datas\\week4Sch.txt");
    for(int x=0; x<5; x++){
        for(int y=0; y<3; y++){
            for(int z=0; z<2; z++){
                line+=schedule4[x][y][z];
                if(z!=1)
                    line+=" ";
            }
            WriteFileSCH4 << line << endl;
            line="";
        }
        WriteFileSCH4 << endl;
    }
    WriteFileSCH4.close();
    line="";

    ofstream WriteFileBKK4("datas\\BKKweek4.txt");
    for(int x=0; x<5; x++){
        for(int y=0; y<3; y++){
            for(int z=0; z<6; z++){
                line+=booking4[x][y][z];
                //if last element no need add space
                if(z!=5)
                    line+=" ";
            }
            WriteFileBKK4 << line << endl;
            line="";
        }
        WriteFileBKK4 << endl;
    }
    WriteFileBKK4.close();
    line="";

    //redirect to homepage in 10 seconds
    for(int i=10; i>0; i--){
        cls();logo();
        SetConsoleTextAttribute(color, 10);
        cout << "Booking Confirmed!" << endl;
        SetConsoleTextAttribute(color, 15);
        cout << left << setw(20) << "Name" << " : " << name << endl;
        cout << left << setw(20) << "Booking ID" << " : " << bookingID << endl;
        cout << left << setw(20) << "Service" << " : " << servicename << endl;
        cout << left << setw(20) << "Expert Name" << " : " << expertName << endl;
        cout << left << setw(20) << "Date" << " : " << date << " July, " << day << endl;
        cout << "You will be redirected to home page in ";
        SetConsoleTextAttribute(color, 10);
        cout << i << "....." << endl;
        SetConsoleTextAttribute(color, 15);
        Sleep(1000);
    }
}

string genBKKno(char serviceType){
    string bookingNO;
    bool validNO = false;
    switch(serviceType){
        case 'T':
            while(!validNO){
                bookingNO = "T";
                srand(time(0));
                //generate random bookingNO
                bookingNO+=to_string(rand()%100+1);

                //checking if bookingNO is in the bkkNumber array
                for(int i=0; i<100; i++){
                    if(bkkNumber[i] == bookingNO){
                        validNO = false;
                        i=100;
                    }
                    else
                        validNO = true;
                }  

            }

            //after generating a valid booking number add the number to the array
            for(int i=0; i<100; i++){
                if(bkkNumber[i][0] != 'T' && bkkNumber[i][0] != 'C'){
                    bkkNumber[i] = bookingNO;
                    i=100;
                }
            }
            break;


        case 'C':
            while(!validNO){
                bookingNO = "C";
                srand(time(0));
                //generate random bookingNO
                bookingNO+=to_string(rand()%100+1);

                //checking if bookingNO is in the bkkNumber array
                for(int i=0; i<100; i++){
                    if(bkkNumber[i] == bookingNO){
                        validNO = false;
                        i=100;
                    }
                    else
                        validNO = true;
                }  
            }
            for(int i=0; i<100; i++){
                if(bkkNumber[i][0] != 'T' && bkkNumber[i][0] != 'C'){
                    bkkNumber[i] = bookingNO;
                    i=100;
                }
            }
            break;

    }

    return bookingNO;
}

void showAvailableDates(string services, int week, string servicename){
    int service = stoi(services);
    string bookingChoice;
    string customerName;
    string customerEmail;
    string expertName;
    string servicetype = service == 1? "Treatment" : "Consultation";
    bool validEmail = false;
    bool validBooking = false;
    bool book_or_not= false;

    //{name, monday, tuesday, wed, thurs, fri}
    string Adam[6];
    string Britney[6];
    string Catherine[6];

    cls();logo();


    switch(week){
        //if week 1
        case 1:
            cout << "Generating Schedules";
            switch(service){
                //treatment
                case 1:
                    for(int i=0; i<6; i++){
                        if(i==0){
                            Adam[i] = "Adam";
                            Britney[i] = "Britney";
                            Catherine[i] = "Catherine";
                        }else{
                            //is adam monday/tuesday/wed available? for treatment
                            cout << "..";
                            string bookingNO;
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule1[0][0][0]) + stoi(schedule1[0][0][1]) + stoi(schedule1[1][0][0]) + stoi(schedule1[1][0][1]) + stoi(schedule1[2][0][0]) + stoi(schedule1[2][0][1]) + stoi(schedule1[3][0][0]) + stoi(schedule1[3][0][1]) + stoi(schedule1[4][0][0]) + stoi(schedule1[4][0][1]))>=2)
                                Adam[i] = (6-(stoi(schedule1[i-1][0][0])+stoi(schedule1[i-1][0][1])))>=2? bookingNO : "NA";
                            else
                                Adam[i] = "NA";

                            cls();logo();
                            cout << "Generating Schedules";
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule1[0][1][0]) + stoi(schedule1[0][1][1]) + stoi(schedule1[1][1][0]) + stoi(schedule1[1][1][1]) + stoi(schedule1[2][1][0]) + stoi(schedule1[2][1][1]) + stoi(schedule1[3][1][0]) + stoi(schedule1[3][1][1]) + stoi(schedule1[4][1][0]) + stoi(schedule1[4][1][1]))>=2)
                                Britney[i] = (6-(stoi(schedule1[i-1][1][0])+stoi(schedule1[i-1][1][1])))>=2? bookingNO : "NA";
                            else
                                Britney[i] = "NA";

                            cout << "..";
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule1[0][2][0]) + stoi(schedule1[0][2][1]) + stoi(schedule1[1][2][0]) + stoi(schedule1[1][2][1]) + stoi(schedule1[2][2][0]) + stoi(schedule1[2][2][1]) + stoi(schedule1[3][2][0]) + stoi(schedule1[3][2][1]) + stoi(schedule1[4][2][0]) + stoi(schedule1[4][2][1]))>=2)
                                Catherine[i] = (6-(stoi(schedule1[i-1][2][0])+stoi(schedule1[i-1][2][1])))>=2? bookingNO : "NA";
                            else
                                Catherine[i] = "NA";
                        }
                    }
                    break;

                //consultation
                case 2:
                    for(int i=0; i<6; i++){
                        if(i==0){
                            Adam[i] = "Adam";
                            Britney[i] = "Britney";
                            Catherine[i] = "Catherine";
                        }else{
                            //is adam monday/tuesday/wed available? for treatment
                            cout << "..";
                            string bookingNO;
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule1[0][0][0]) + stoi(schedule1[0][0][1]) + stoi(schedule1[1][0][0]) + stoi(schedule1[1][0][1]) + stoi(schedule1[2][0][0]) + stoi(schedule1[2][0][1]) + stoi(schedule1[3][0][0]) + stoi(schedule1[3][0][1]) + stoi(schedule1[4][0][0]) + stoi(schedule1[4][0][1]))>=1)
                                Adam[i] = (6-(stoi(schedule1[i-1][0][0])+stoi(schedule1[i-1][0][1])))>=1? bookingNO : "NA";
                            else
                                Adam[i] = "NA";

                            cls();logo();
                            cout << "Generating Schedules";
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule1[0][1][0]) + stoi(schedule1[0][1][1]) + stoi(schedule1[1][1][0]) + stoi(schedule1[1][1][1]) + stoi(schedule1[2][1][0]) + stoi(schedule1[2][1][1]) + stoi(schedule1[3][1][0]) + stoi(schedule1[3][1][1]) + stoi(schedule1[4][1][0]) + stoi(schedule1[4][1][1]))>=1)
                                Britney[i] = (6-(stoi(schedule1[i-1][1][0])+stoi(schedule1[i-1][1][1])))>=1? bookingNO : "NA";
                            else
                                Britney[i] = "NA";

                            cout << "..";
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule1[0][2][0]) + stoi(schedule1[0][2][1]) + stoi(schedule1[1][2][0]) + stoi(schedule1[1][2][1]) + stoi(schedule1[2][2][0]) + stoi(schedule1[2][2][1]) + stoi(schedule1[3][2][0]) + stoi(schedule1[3][2][1]) + stoi(schedule1[4][2][0]) + stoi(schedule1[4][2][1]))>=1)
                                Catherine[i] = (6-(stoi(schedule1[i-1][2][0])+stoi(schedule1[i-1][2][1])))>=1? bookingNO : "NA";
                            else
                                Catherine[i] = "NA";

                        }
                    }
                    break;
            }
            cls();logo();
            cout << setw(55) << "WEEK 1" << endl;
            break;

        //if week 2 and so on
        case 2:
            cout << "Generating Schedules";
            switch(service){
                //treatment
                case 1:
                    for(int i=0; i<6; i++){
                        if(i==0){
                            Adam[i] = "Adam";
                            Britney[i] = "Britney";
                            Catherine[i] = "Catherine";
                        }else{
                            //is adam monday/tuesday/wed available? for treatment
                            string bookingNO;
                            cout << "..";
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule2[0][0][0]) + stoi(schedule2[0][0][1]) + stoi(schedule2[1][0][0]) + stoi(schedule2[1][0][1]) + stoi(schedule2[2][0][0]) + stoi(schedule2[2][0][1]) + stoi(schedule2[3][0][0]) + stoi(schedule2[3][0][1]) + stoi(schedule2[4][0][0]) + stoi(schedule2[4][0][1]))>=2)
                                Adam[i] = (6-(stoi(schedule2[i-1][0][0])+stoi(schedule2[i-1][0][1])))>=2? bookingNO : "NA";
                            else
                                Adam[i] = "NA";

                            cls();logo();
                            cout << "Generating Schedules";
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule2[0][1][0]) + stoi(schedule2[0][1][1]) + stoi(schedule2[1][1][0]) + stoi(schedule2[1][1][1]) + stoi(schedule2[2][1][0]) + stoi(schedule2[2][1][1]) + stoi(schedule2[3][1][0]) + stoi(schedule2[3][1][1]) + stoi(schedule2[4][1][0]) + stoi(schedule2[4][1][1]))>=2)
                                Britney[i] = (6-(stoi(schedule2[i-1][1][0])+stoi(schedule2[i-1][1][1])))>=2? bookingNO : "NA";
                            else
                                Britney[i] = "NA";

                            cout << "..";
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule2[0][2][0]) + stoi(schedule2[0][2][1]) + stoi(schedule2[1][2][0]) + stoi(schedule2[1][2][1]) + stoi(schedule2[2][2][0]) + stoi(schedule2[2][2][1]) + stoi(schedule2[3][2][0]) + stoi(schedule2[3][2][1]) + stoi(schedule2[4][2][0]) + stoi(schedule2[4][2][1]))>=2)
                                Catherine[i] = (6-(stoi(schedule2[i-1][2][0])+stoi(schedule2[i-1][2][1])))>=2? bookingNO : "NA";
                            else
                                Catherine[i] = "NA";
                        }
                    }
                    break;

                //consultation
                case 2:
                    for(int i=0; i<6; i++){
                        if(i==0){
                            Adam[i] = "Adam";
                            Britney[i] = "Britney";
                            Catherine[i] = "Catherine";
                        }else{
                            //is adam monday/tuesday/wed available? for treatment
                            cout << "..";
                            string bookingNO;
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule2[0][0][0]) + stoi(schedule2[0][0][1]) + stoi(schedule2[1][0][0]) + stoi(schedule2[1][0][1]) + stoi(schedule2[2][0][0]) + stoi(schedule2[2][0][1]) + stoi(schedule2[3][0][0]) + stoi(schedule2[3][0][1]) + stoi(schedule2[4][0][0]) + stoi(schedule2[4][0][1]))>=1)
                                Adam[i] = (6-(stoi(schedule2[i-1][0][0])+stoi(schedule2[i-1][0][1])))>=1? bookingNO : "NA";
                            else
                                Adam[i] = "NA";

                            cls();logo();
                            cout << "Generating Schedules";
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule2[0][1][0]) + stoi(schedule2[0][1][1]) + stoi(schedule2[1][1][0]) + stoi(schedule2[1][1][1]) + stoi(schedule2[2][1][0]) + stoi(schedule2[2][1][1]) + stoi(schedule2[3][1][0]) + stoi(schedule2[3][1][1]) + stoi(schedule2[4][1][0]) + stoi(schedule2[4][1][1]))>=1)
                                Britney[i] = (6-(stoi(schedule2[i-1][1][0])+stoi(schedule2[i-1][1][1])))>=1? bookingNO : "NA";
                            else
                                Britney[i] = "NA";

                            cout << "..";
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule2[0][2][0]) + stoi(schedule2[0][2][1]) + stoi(schedule2[1][2][0]) + stoi(schedule2[1][2][1]) + stoi(schedule2[2][2][0]) + stoi(schedule2[2][2][1]) + stoi(schedule2[3][2][0]) + stoi(schedule2[3][2][1]) + stoi(schedule2[4][2][0]) + stoi(schedule2[4][2][1]))>=1)
                                Catherine[i] = (6-(stoi(schedule2[i-1][2][0])+stoi(schedule2[i-1][2][1])))>=1? bookingNO : "NA";
                            else
                                Catherine[i] = "NA";

                        }
                    }
                    break;
            }
            cls();logo();
            cout << setw(55) << "WEEK 2" << endl;
            break;


        case 3:
            cout << "Generating Schedules";
            switch(service){
                //treatment
                case 1:
                    for(int i=0; i<6; i++){
                        if(i==0){
                            Adam[i] = "Adam";
                            Britney[i] = "Britney";
                            Catherine[i] = "Catherine";
                        }else{
                            //is adam monday/tuesday/wed available? for treatment
                            cout << "..";
                            string bookingNO;
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule3[0][0][0]) + stoi(schedule3[0][0][1]) + stoi(schedule3[1][0][0]) + stoi(schedule3[1][0][1]) + stoi(schedule3[2][0][0]) + stoi(schedule3[2][0][1]) + stoi(schedule3[3][0][0]) + stoi(schedule3[3][0][1]) + stoi(schedule3[4][0][0]) + stoi(schedule3[4][0][1]))>=2)
                                Adam[i] = (6-(stoi(schedule3[i-1][0][0])+stoi(schedule3[i-1][0][1])))>=2? bookingNO : "NA";
                            else
                                Adam[i] = "NA";

                            cls();logo();
                            cout << "Generating Schedules";
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule3[0][1][0]) + stoi(schedule3[0][1][1]) + stoi(schedule3[1][1][0]) + stoi(schedule3[1][1][1]) + stoi(schedule3[2][1][0]) + stoi(schedule3[2][1][1]) + stoi(schedule3[3][1][0]) + stoi(schedule3[3][1][1]) + stoi(schedule3[4][1][0]) + stoi(schedule3[4][1][1]))>=2)
                                Britney[i] = (6-(stoi(schedule3[i-1][1][0])+stoi(schedule3[i-1][1][1])))>=2? bookingNO : "NA";
                            else
                                Britney[i] = "NA";

                            cout << "..";
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule3[0][2][0]) + stoi(schedule3[0][2][1]) + stoi(schedule3[1][2][0]) + stoi(schedule3[1][2][1]) + stoi(schedule3[2][2][0]) + stoi(schedule3[2][2][1]) + stoi(schedule3[3][2][0]) + stoi(schedule3[3][2][1]) + stoi(schedule3[4][2][0]) + stoi(schedule3[4][2][1]))>=2)
                                Catherine[i] = (6-(stoi(schedule3[i-1][2][0])+stoi(schedule3[i-1][2][1])))>=2? bookingNO : "NA";
                            else
                                Catherine[i] = "NA";

                        }
                    }
                    break;

                //consultation
                case 2:
                    for(int i=0; i<6; i++){
                        if(i==0){
                            Adam[i] = "Adam";
                            Britney[i] = "Britney";
                            Catherine[i] = "Catherine";
                        }else{
                            //is adam monday/tuesday/wed available? for treatment
                            cout << "..";
                            string bookingNO;
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule3[0][0][0]) + stoi(schedule3[0][0][1]) + stoi(schedule3[1][0][0]) + stoi(schedule3[1][0][1]) + stoi(schedule3[2][0][0]) + stoi(schedule3[2][0][1]) + stoi(schedule3[3][0][0]) + stoi(schedule3[3][0][1]) + stoi(schedule3[4][0][0]) + stoi(schedule3[4][0][1]))>=1)
                                Adam[i] = (6-(stoi(schedule3[i-1][0][0])+stoi(schedule3[i-1][0][1])))>=1? bookingNO : "NA";
                            else
                                Adam[i] = "NA";

                            cls();logo();
                            cout << "Generating Schedules";
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule3[0][1][0]) + stoi(schedule3[0][1][1]) + stoi(schedule3[1][1][0]) + stoi(schedule3[1][1][1]) + stoi(schedule3[2][1][0]) + stoi(schedule3[2][1][1]) + stoi(schedule3[3][1][0]) + stoi(schedule3[3][1][1]) + stoi(schedule3[4][1][0]) + stoi(schedule3[4][1][1]))>=1)
                                Britney[i] = (6-(stoi(schedule3[i-1][1][0])+stoi(schedule3[i-1][1][1])))>=1? bookingNO : "NA";
                            else
                                Britney[i] = "NA";

                            cout << "..";
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule3[0][2][0]) + stoi(schedule3[0][2][1]) + stoi(schedule3[1][2][0]) + stoi(schedule3[1][2][1]) + stoi(schedule3[2][2][0]) + stoi(schedule3[2][2][1]) + stoi(schedule3[3][2][0]) + stoi(schedule3[3][2][1]) + stoi(schedule3[4][2][0]) + stoi(schedule3[4][2][1]))>=1)
                                Catherine[i] = (6-(stoi(schedule3[i-1][2][0])+stoi(schedule3[i-1][2][1])))>=1? bookingNO : "NA";
                            else
                                Catherine[i] = "NA";

                        }
                    }
                    break;
            }
            cls();logo();
            cout << setw(55) << "WEEK 3" << endl;
            break;



        case 4:
            cout << "Generating Schedules";
            switch(service){
                //treatment
                case 1:
                    for(int i=0; i<6; i++){
                        if(i==0){
                            Adam[i] = "Adam";
                            Britney[i] = "Britney";
                            Catherine[i] = "Catherine";
                        }else{
                            //is adam monday/tuesday/wed available? for treatment
                            cout << "..";
                            string bookingNO;
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule4[0][0][0]) + stoi(schedule4[0][0][1]) + stoi(schedule4[1][0][0]) + stoi(schedule4[1][0][1]) + stoi(schedule4[2][0][0]) + stoi(schedule4[2][0][1]) + stoi(schedule4[3][0][0]) + stoi(schedule4[3][0][1]) + stoi(schedule4[4][0][0]) + stoi(schedule4[4][0][1]))>=2)
                                Adam[i] = (6-(stoi(schedule4[i-1][0][0])+stoi(schedule4[i-1][0][1])))>=2? bookingNO : "NA";
                            else
                                Adam[i] = "NA";

                            cls();logo();
                            cout << "Generating Schedules";
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule4[0][1][0]) + stoi(schedule4[0][1][1]) + stoi(schedule4[1][1][0]) + stoi(schedule4[1][1][1]) + stoi(schedule4[2][1][0]) + stoi(schedule4[2][1][1]) + stoi(schedule4[3][1][0]) + stoi(schedule4[3][1][1]) + stoi(schedule4[4][1][0]) + stoi(schedule4[4][1][1]))>=2)
                                Britney[i] = (6-(stoi(schedule4[i-1][1][0])+stoi(schedule4[i-1][1][1])))>=2? bookingNO : "NA";
                            else
                                Britney[i] = "NA";

                            cout << "..";
                            bookingNO = genBKKno('T');
                            if(30-( stoi(schedule4[0][2][0]) + stoi(schedule4[0][2][1]) + stoi(schedule4[1][2][0]) + stoi(schedule4[1][2][1]) + stoi(schedule4[2][2][0]) + stoi(schedule4[2][2][1]) + stoi(schedule4[3][2][0]) + stoi(schedule4[3][2][1]) + stoi(schedule4[4][2][0]) + stoi(schedule4[4][2][1]))>=2)
                                Catherine[i] = (6-(stoi(schedule4[i-1][2][0])+stoi(schedule4[i-1][2][1])))>=2? bookingNO : "NA";
                            else
                                Catherine[i] = "NA";
                        }
                    }
                    break;

                //consultation
                case 2:
                    for(int i=0; i<6; i++){
                        if(i==0){
                            Adam[i] = "Adam";
                            Britney[i] = "Britney";
                            Catherine[i] = "Catherine";
                        }else{
                            //is adam monday/tuesday/wed available? for treatment
                            cout << "..";
                            string bookingNO;
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule4[0][0][0]) + stoi(schedule4[0][0][1]) + stoi(schedule4[1][0][0]) + stoi(schedule4[1][0][1]) + stoi(schedule4[2][0][0]) + stoi(schedule4[2][0][1]) + stoi(schedule4[3][0][0]) + stoi(schedule4[3][0][1]) + stoi(schedule4[4][0][0]) + stoi(schedule4[4][0][1]))>=1)
                                Adam[i] = (6-(stoi(schedule4[i-1][0][0])+stoi(schedule4[i-1][0][1])))>=1? bookingNO : "NA";
                            else
                                Adam[i] = "NA";

                            cls();logo();
                            cout << "Generating Schedules";
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule4[0][1][0]) + stoi(schedule4[0][1][1]) + stoi(schedule4[1][1][0]) + stoi(schedule4[1][1][1]) + stoi(schedule4[2][1][0]) + stoi(schedule4[2][1][1]) + stoi(schedule4[3][1][0]) + stoi(schedule4[3][1][1]) + stoi(schedule4[4][1][0]) + stoi(schedule4[4][1][1]))>=1)
                                Britney[i] = (6-(stoi(schedule4[i-1][1][0])+stoi(schedule4[i-1][1][1])))>=1? bookingNO : "NA";
                            else
                                Britney[i] = "NA";

                            cout << "..";
                            bookingNO = genBKKno('C');
                            if(30-( stoi(schedule4[0][2][0]) + stoi(schedule4[0][2][1]) + stoi(schedule4[1][2][0]) + stoi(schedule4[1][2][1]) + stoi(schedule4[2][2][0]) + stoi(schedule4[2][2][1]) + stoi(schedule4[3][2][0]) + stoi(schedule4[3][2][1]) + stoi(schedule4[4][2][0]) + stoi(schedule4[4][2][1]))>=1)
                                Catherine[i] = (6-(stoi(schedule4[i-1][2][0])+stoi(schedule4[i-1][2][1])))>=1? bookingNO : "NA";
                            else
                                Catherine[i] = "NA";
                        }
                    }
                    break;
            }
            cls();logo();
            cout << setw(55) << "WEEK 4" << endl;
            break;
    }

    vector<string> vecAdam(Adam, Adam + 6);
    vector<string> vecBritney(Britney, Britney + 6);
    vector<string> vecCatherine(Catherine, Catherine + 6);

    Table AvailSchedules;
    AvailSchedules.headers = {"Experts", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    AvailSchedules.add_content(vecAdam);
    AvailSchedules.add_content(vecBritney);
    AvailSchedules.add_content(vecCatherine);
    AvailSchedules.tabulate();

    do{
        cout << "\nPlease Select A Booking Number: ";
        cin >> bookingChoice;
        for(auto& c:bookingChoice){
            c = toupper(c);
        }

        for(int i=1; i<6; i++){
            if(bookingChoice==Adam[i] && Adam[i]!= "NA")
                validBooking=true;
            else if(bookingChoice==Britney[i] && Britney[i]!= "NA")
                validBooking=true;
            else if(bookingChoice==Catherine[i] && Catherine[i]!= "NA")
                validBooking=true;
        }
        if(!validBooking){
            cls();logo();
            AvailSchedules.tabulate();
            SetConsoleTextAttribute(color, 4);
            cout << "\nInvalid Booking Number!";
            SetConsoleTextAttribute(color, 15);
        }
    }while(!validBooking);

    cls();logo();
    SetConsoleTextAttribute(color, 10);
    cout << "\nCONTACT INFORMATION" << endl;
    SetConsoleTextAttribute(color, 15);
    cout << "Please Enter Your Name : ";
    cin.get();
    getline(cin, customerName);
    do{
        cout << "Please Enter Your Email : ";
        cin >> customerEmail;
        validEmail = validateEmail(customerEmail);
        if(!validEmail){
            cls();logo();
            SetConsoleTextAttribute(color, 10);
            cout << "\nCONTACT INFORMATION" << endl;
            SetConsoleTextAttribute(color, 15);
            cout << "Please Enter Your Name : " << customerName << endl;
            SetConsoleTextAttribute(color, 4);
            cout << "Invalid Email!" << endl;
            SetConsoleTextAttribute(color, 15);
        }
    }while(!validEmail);

    //calculate the day and date and price of bookingChoice selected;
    string day;
    int date;
    enum Prices price;
    //calculate price
    if(service==1){
        if(servicename == "HAIR STYLING")
            price = HAIR;
        else if(servicename == "NAIL DESIGN")
            price = NAIL;
        else
            price = WRAP;
    }else{
        price = CONSULT;
    }

    //calculate day and date
    for(int i=1; i<6; i++){
        if(Adam[i] == bookingChoice || Britney[i] == bookingChoice || Catherine[i] == bookingChoice){
            if(i==1){
                day = "Monday";
                date = 1+(week-1)*7;
            }
            else if(i==2){
                day = "Tuesday";
                date = 2+(week-1)*7;
            }
            else if(i==3){
                day = "Wednesday";
                date = 3+(week-1)*7;
            }
            else if(i==4){
                day = "Thursday";
                date = 4+(week-1)*7;
            }
            else{
                day = "Friday";
                date = 5+(week-1)*7;
            }
        }
    }

    //see which expert belongs to that booking id
    for(int i=1; i<6; i++){
        if(Adam[i] == bookingChoice)
            expertName = "ADAM";
        else if(Britney[i] == bookingChoice)
            expertName = "BRITNEY";
        else if(Catherine[i] == bookingChoice)
            expertName = "CATHERINE";
    }


    book_or_not = cfmBooking(customerName, customerEmail, bookingChoice, servicename, service, date, day, (double) price);
    if(book_or_not){
        if(paymentpage((double) price, bookingChoice))
            logBooking(customerName,bookingChoice,servicename,week,day,date,expertName,customerEmail,servicetype, to_string(price));
        //settle
    }
    else;
        
}

void bookService(int service, int choice, string servicename){
    if (choice == 'y'){
        string input="1";
        int weekChoice;
        do{
            cls();logo();
            if(input!= "1" && input!="2"){
                SetConsoleTextAttribute(color, 4);
                cout << "Invalid Choice!" << endl;
                SetConsoleTextAttribute(color, 15);
            }
            cout << "Meet Expert For : " << endl;
            cout << "[1] Treatment" << endl;
            cout << "[2] Consultation" << endl;
            cout << "\nEnter Your Choice : ";
            cin >> input;
        }while(input!= "1" && input!="2");

        Table weeks;
        weeks.headers = {"JULY 2024", "Dates"};
        weeks.add_content({"Week 1","Day 1 - 5"});
        weeks.add_content({"Week 2","Day 8 - 12"});
        weeks.add_content({"Week 3","Day 15 - 19"});
        weeks.add_content({"Week 4","Day 22 - 26"});
        cls();logo();
        weeks.tabulate();
        while(true){
            cout << "Select A Week Of Your Choice : ";
            cin >> weekChoice;
            if(cin.fail()){
                cin.clear();
                cin.ignore(100,'\n');
                cls();logo();
                weeks.tabulate();
                SetConsoleTextAttribute(color, 4);
                cout << "Invalid Input!" << endl;
                SetConsoleTextAttribute(color, 15);             
            }else{
                if(weekChoice<1 || weekChoice>4){
                    cls();logo();
                    weeks.tabulate();
                    SetConsoleTextAttribute(color, 4);
                    cout << "Invalid Choice!" << endl;
                    SetConsoleTextAttribute(color, 15);
                }else{
                    break;
                }
            }
        }

        showAvailableDates(input, weekChoice, servicename);
        

    }
    else{
        return;
    }

}

void servicesdesc(int x){
    char input;
    bool invalid_input = false;
    string servicename = services[x-1][0];
    string servicedesc = services[x-1][1];

    while(true){
        cls();logo();
        for(char& c : servicename){
            c = toupper(c);
        }

        cout << servicename << endl << endl;
        for(int i=0; i<servicedesc.size(); i++){
            if(i%70 == 0){
                cout << endl;
                if(servicedesc[i] == ' ')
                    continue;
                }
            cout << servicedesc[i];
        }

        cout << "\n\n";
        if(invalid_input){
            SetConsoleTextAttribute(color, 4);
            cout << "Invalid Input!" << endl;
            SetConsoleTextAttribute(color, 15);
        }
        cout << "Are you interested? [y/n] : ";
        cin >> input;
        input = tolower(input);
        if(input == 'y' || input == 'n')
            break;
        else
            invalid_input = true;
    }

    bookService(x-0, tolower(input), servicename);

    
    
}


void c_viewServices(){
    cls(); logo();
    int input;
    Table serviceList;
    serviceList.headers = {"Our Services List"};
    serviceList.add_content({"Hair Styling"});
    serviceList.add_content({"Nail Design"});
    serviceList.add_content({"Body Wrap"});
    serviceList.add_content({"Customer Menu"});
    serviceList.tabulate();

    while(true){
    cout << "Please Select A Service: ";
    cin >> input;

    if(cin.fail()){
        //clearing the buffers incase fail
        cin.clear();
        cin.ignore(100,'\n');
        cls();
        logo();
        serviceList.tabulate();
        SetConsoleTextAttribute(color, 4);
        cout << "Error! Enter Valid Numbers Only." << endl;
        SetConsoleTextAttribute(color, 15);
    }else{
        //if cin buffer no error then check if number within valid range
        if(input < 1 || input > 4){
            cls();
            logo();
            serviceList.tabulate();
            SetConsoleTextAttribute(color, 4);
            cout << "Error! Enter Valid Numbers Only." << endl;
            SetConsoleTextAttribute(color, 15);
        }else{
            switch(input){
                case 1:
                    servicesdesc(input);
                    cls();
                    logo();
                    serviceList.tabulate();
                    break;
                case 2:
                    servicesdesc(input);
                    cls();
                    logo();
                    serviceList.tabulate();
                    break;
                case 3:
                    servicesdesc(input);
                    cls();
                    logo();
                    serviceList.tabulate();
                    break;
                case 4:
                    return;
            }
        }
    }
    }


}

void c_viewExperts(){
    int input;

    Table expert;
    expert.headers = {"Experts"};
    for(int i=0; i<experts_size; i++){
        string name = experts[i][0];
        expert.add_content({name});
    }
    expert.add_content({"Customer Menu"});

    cls();
    logo();
    expert.tabulate();

    while(true){
        cout << "Please Select : ";
        cin >> input;
        if(cin.fail()){
            //clearing the buffers incase fail
            cin.clear();
            cin.ignore(100,'\n');
            cls();
            logo();
            expert.tabulate();
            SetConsoleTextAttribute(color, 4);
            cout << "Error! Enter Valid Numbers Only." << endl;
            SetConsoleTextAttribute(color, 15);
        }else{
            //if cin buffer no error then check if number within valid range
            if(input < 1 || input > 4){
                cls();
                logo();
                expert.tabulate();
                SetConsoleTextAttribute(color, 4);
                cout << "Error! Enter Valid Numbers Only." << endl;
                SetConsoleTextAttribute(color, 15);
            }else{
                switch(input){
                    case 1:
                        expertdesc(input);
                        cls();
                        logo();
                        expert.tabulate();
                        break;
                    case 2:
                        expertdesc(input);
                        cls();
                        logo();
                        expert.tabulate();
                        break;
                    case 3:
                        expertdesc(input);
                        cls();
                        logo();
                        expert.tabulate();
                        break;
                    case 4:
                        return;
                 }
            }
        }
    }

}

void c_viewAppointment(){
    bool bookingFound = false;
    string bookInput;

    Table showBookings;
    showBookings.headers = {"Booking NO","Name", "Contact","Service","Type","Expert Name","Date","Status"};
    cls();logo();
    do{
        cout << "Enter Your Booking Number (-999 to go back): ";
        cin >> bookInput;
        if(bookInput == "-999")
            return;
        //turning the input into upper case
        for(char& c:bookInput){
            c = toupper(c);
        }

        //searching for the booking number in the appointment table
        for(int i=0; i<100; i++){
            if(appointments[i][0] == bookInput){
                bookingFound = true;
                string date = appointments[i][7]+" July 2024";
                showBookings.add_content({appointments[i][0],appointments[i][1],appointments[i][2],appointments[i][3],appointments[i][4],appointments[i][5],date,"Confirmed"});
            }
        }

        if(bookingFound){
            cls();logo();
            showBookings.tabulate();
            cout << "Enter any key to go back : ";
            getch();
            return;
        }
        else{
            cls();logo();
            cout << "No Booking Found!" << endl;
        }
    }while(!bookingFound);
    
}

void customer_page(){
    cls();
    logo();
    int input;

    Table customer_menu;
    customer_menu.headers = {"Customer Services"};
    customer_menu.add_content({"View Services"});
    customer_menu.add_content({"View Experts"});
    customer_menu.add_content({"View Appointment"});
    customer_menu.add_content({"Main Menu"});
    customer_menu.tabulate();

    while(true){
        cout << "Please Select : ";
        cin >> input;

        if(cin.fail()){
            //clearing the buffers incase fail
            cin.clear();
            cin.ignore(100,'\n');
            cls();
            logo();
            customer_menu.tabulate();
            SetConsoleTextAttribute(color, 4);
            cout << "Error! Enter Valid Numbers Only." << endl;
            SetConsoleTextAttribute(color, 15);
        }else{
            //if cin buffer no error then check if number within valid range
            if(input < 1 || input > 4){
                cls();
                logo();
                customer_menu.tabulate();
                SetConsoleTextAttribute(color, 4);
                cout << "Error! Enter Valid Numbers Only." << endl;
                SetConsoleTextAttribute(color, 15);
            }else{
                switch(input){
                    case 1:
                        c_viewServices();
                        cls();logo();customer_menu.tabulate();
                        break;
                    case 2:
                        c_viewExperts();
                        cls();logo();customer_menu.tabulate();
                        break;
                    case 3:
                        c_viewAppointment();
                        cls();logo();customer_menu.tabulate();
                        break;
                    case 4:
                        return;
                }
            }
        }
    }

}

void showTreatmentSch(string staffname){
    cls();logo();bbsort(appointments, 100);
    char NameFirstLetter = staffname[0];

    Table s_treatment;
    s_treatment.headers = {"Booking NO", "Customer Name", "Contact", "Treatment", "Date"};
    
    switch(NameFirstLetter){
        //if is adam then show add adam schedule to the content
        case 'A':
            for(int i=0; i<100; i++){
                //loop through each booking and see if expert name starts with 'a' and if servicetype start with 't'
                if(tolower((appointments[i][5])[0]) == 'a' && tolower((appointments[i][0])[0]) == 't'){
                    string date = appointments[i][7] + " July 2024";
                    s_treatment.add_content({appointments[i][0],appointments[i][1],appointments[i][2],appointments[i][3],date});
                }
            }
            break;

        case 'B':
            for(int i=0; i<100; i++){
                if(tolower((appointments[i][5])[0]) == 'b' && tolower((appointments[i][0])[0]) == 't'){
                    string date = appointments[i][7] + " July 2024";
                    s_treatment.add_content({appointments[i][0],appointments[i][1],appointments[i][2],appointments[i][3],date});
                }
            }
            break;



        case 'C':
            for(int i=0; i<100; i++){
                if(tolower((appointments[i][5])[0]) == 'c' && tolower((appointments[i][0])[0]) == 't'){
                    string date = appointments[i][7] + " July 2024";
                    s_treatment.add_content({appointments[i][0],appointments[i][1],appointments[i][2],appointments[i][3],date});
                }
            }
            break;

    }
    s_treatment.tabulate();

    //Enter any key to go back;
    cout << "Enter any key to go back : ";
    getch();
}


void showConsultationSch(string staffname){
    cls();logo();bbsort(appointments, 100);
    char NameFirstLetter = staffname[0];

    Table s_consult;
    s_consult.headers = {"Booking NO", "Customer Name", "Contact", "Consultation", "Date"};
    
    switch(NameFirstLetter){
        //if is adam then show add adam schedule to the content
        case 'A':
            for(int i=0; i<100; i++){
                //loop through each booking and see if expert name starts with 'a' and if servicetype start with 't'
                if(tolower((appointments[i][5])[0]) == 'a' && tolower((appointments[i][0])[0]) == 'c'){
                    string date = appointments[i][7] + " July 2024";
                    s_consult.add_content({appointments[i][0],appointments[i][1],appointments[i][2],appointments[i][3],date});
                }
            }
            break;

        case 'B':
            for(int i=0; i<100; i++){
                if(tolower((appointments[i][5])[0]) == 'b' && tolower((appointments[i][0])[0]) == 'c'){
                    string date = appointments[i][7] + " July 2024";
                    s_consult.add_content({appointments[i][0],appointments[i][1],appointments[i][2],appointments[i][3],date});
                }
            }
            break;



        case 'C':
            for(int i=0; i<100; i++){
                if(tolower((appointments[i][5])[0]) == 'c' && tolower((appointments[i][0])[0]) == 'c'){
                    string date = appointments[i][7] + " July 2024";
                    s_consult.add_content({appointments[i][0],appointments[i][1],appointments[i][2],appointments[i][3],date});
                }
            }
            break;
    }
    s_consult.tabulate();

    //Enter any key to go back;
    cout << "Enter any key to go back : ";
    getch();
}

void showOverallSch(){
    cls();logo();bbsort(appointments, 100);
    
    Table s_overall;
    s_overall.headers = {"Booking NO", "Expert Name","Customer Name", "Contact", "Consultation", "Date"};
    
    for(int i=0; i<100; i++){
        //loop through each booking and see if expert name starts with 'a' and if servicetype start with 't'
        if(appointments[i][0]!=""){
            string date = appointments[i][7] + " July 2024";
            s_overall.add_content({appointments[i][0],appointments[i][5],appointments[i][1],appointments[i][2],appointments[i][3],date});
        }

    }

    s_overall.tabulate();

    //Enter any key to go back;
    cout << "Enter any key to go back : ";
    getch();
}

void showSalesReport(string staffname){
    cls();logo();
    char NameFirstLetter = staffname[0];
    int totalTreatment=0, totalConsultation=0;
    double totalSales=0.00, totalProfit=0.00, averageSales=0.00;

    Table salesReport;
    salesReport.headers = {"Name", "Total Treatment", "Total Consultation", "Total Sales", "Total Profit", "Average Sales"};
    for(int i=0; i<100; i++){
        //loop through each row of appointment, if first thing not empty string and matches staffname
        if(appointments[i][0] != "" && appointments[i][5][0] == NameFirstLetter){
            if(appointments[i][0][0] == 'T')
                totalTreatment++;
            else
                totalConsultation++;
            totalSales+=stoi(appointments[i][6]);
        }
    }
    totalSales = round(totalSales*100.0)/100.0;
    totalProfit = round((totalSales/2)*100.0)/100.0;
    averageSales = totalSales/(totalTreatment+totalConsultation);
    averageSales = round(averageSales*100.0)/100.0;


    //converting the doubles to strings
    ostringstream stream;
    stream << fixed << setprecision(2) << totalSales;
    string sales = "RM " + stream.str();

    stream.str("");      // Clear the content
    stream.clear(); 

    stream << fixed << setprecision(2) << totalProfit;
    string profit = "RM " + stream.str();

    stream.str("");      // Clear the content
    stream.clear(); 

    stream << fixed << setprecision(2) << averageSales;
    string avgSales = "RM " + stream.str();

    salesReport.add_content({staffname,to_string(totalTreatment),to_string(totalConsultation),sales,profit,avgSales});
    salesReport.tabulate();

    cout << "\nEnter any key to go back : ";
    getch(); 
}

void staffLogin(){
    string username, password;
    int wrongCount = 0;
    char c;

    cls();
    logo();

    do{
        //if wrong more than 3 times then break
        if(wrongCount >=3 || logged_in)
            break;
        //promting for username and password;
        cout << "Enter Username (-999 to go back): ";
        cin >> username;
        if(username == "-999")
            break;
        
        password.clear();
        cout << "Enter Password: ";
        //while character input not enter
        while((c = _getch()) != 13) //enter type
        {
            //if user is entering backspace
            if (c == 8){
                // check if the password string is empty if not then can remove the last character
                if(!password.empty()){
                    password.pop_back();
                    cout << "\b \b";
                }
            }else{
                password+= c;
                SetConsoleTextAttribute(color, 10);
                cout << '*';
                SetConsoleTextAttribute(color, 15);
            }
        }


        //verifying if username and password match
        for(int i=0; i<adminList_size; i++){
            if(username == adminList[i][0]){
                if(password == adminList[i][1]){
                    logged_in = true; 
                    logged_in_user = username;         
                }
                else{
                    cls();
                    logo();
                    wrongCount++;
                    SetConsoleTextAttribute(color, 4);
                    cout << "Invalid Credentials!" << "  Attempt : " << wrongCount+1 << endl;
                    SetConsoleTextAttribute(color, 15);

                }
            }
            else{
                continue;
            }
        }

        //after looping finished and still not verified then say invalid credentials
        if(!logged_in){
            cls();
            logo();
            wrongCount++;
            SetConsoleTextAttribute(color, 4);
            cout << "Invalid Credentials!" << "  Attempt : " << wrongCount+1 << endl;
            SetConsoleTextAttribute(color, 15);
        }
    }while(!logged_in);
    
    if(logged_in){
        cls();logo();
        int input;
        string uppername;
        for(char c:logged_in_user){
            uppername+=toupper(c);
        }
        cout << "Welcome Back, ";
        SetConsoleTextAttribute(color, 5);
        cout << uppername << endl;
        SetConsoleTextAttribute(color, 15);

        Table staffSchedule;
        staffSchedule.headers = {"Services"};
        staffSchedule.add_content({"View Treatment Schedule"});
        staffSchedule.add_content({"View Consultation Schedule"});
        staffSchedule.add_content({"View Overall Schedule"});
        staffSchedule.add_content({"Generate Sales Report"});
        staffSchedule.add_content({"Log Out"});
        staffSchedule.tabulate();

        while(true){
        cout << "Please Select : ";
        cin >> input;

        if(cin.fail()){
            //clearing the buffers incase fail
            cin.clear();
            cin.ignore(100,'\n');
            cls();
            logo();
            cout << "Welcome Back, ";
            SetConsoleTextAttribute(color, 5);
            cout << uppername << endl;
            SetConsoleTextAttribute(color, 15);
            staffSchedule.tabulate();
            SetConsoleTextAttribute(color, 4);
            cout << "Error! Enter Valid Numbers Only." << endl;
            SetConsoleTextAttribute(color, 15);
        }else{
            //if cin buffer no error then check if number within valid range
            if(input < 1 || input > 5){
                cls();
                logo();
                cout << "Welcome Back, ";
                SetConsoleTextAttribute(color, 5);
                cout << uppername << endl;
                SetConsoleTextAttribute(color, 15);
                staffSchedule.tabulate();
                SetConsoleTextAttribute(color, 4);
                cout << "Error! Enter Valid Numbers Only." << endl;
                SetConsoleTextAttribute(color, 15);
            }else{
                switch(input){
                    case 1:
                        showTreatmentSch(uppername);
                        cls();logo();
                        cout << "Welcome Back, ";
                        SetConsoleTextAttribute(color, 5);
                        cout << uppername << endl;
                        SetConsoleTextAttribute(color, 15);
                        staffSchedule.tabulate();
                        break;
                    case 2:
                        showConsultationSch(uppername);
                        cls();logo();
                        cout << "Welcome Back, ";
                        SetConsoleTextAttribute(color, 5);
                        cout << uppername << endl;
                        SetConsoleTextAttribute(color, 15);
                        staffSchedule.tabulate();
                        break;
                    case 3:
                        showOverallSch();
                        cls();logo();
                        cout << "Welcome Back, ";
                        SetConsoleTextAttribute(color, 5);
                        cout << uppername << endl;
                        SetConsoleTextAttribute(color, 15);
                        staffSchedule.tabulate();
                        break;
                    case 4:
                        showSalesReport(uppername);
                        cls();logo();
                        cout << "Welcome Back, ";
                        SetConsoleTextAttribute(color, 5);
                        cout << uppername << endl;
                        SetConsoleTextAttribute(color, 15);
                        staffSchedule.tabulate();
                        break;
                    case 5:
                        logged_in = false;
                        logged_in_user = "";
                        return;

                }
            }
        }
    }
        
    }  
}


void staff_page(){
    int input;

    cls();
    logo();

    Table staff_menu;
    staff_menu.headers = {"Options"};
    staff_menu.add_content({"Login"});
    staff_menu.add_content({"Main Menu"});
    staff_menu.tabulate();

    while(true){
        cout << "Please Select : ";
        cin >> input;

        if(cin.fail()){
            //clearing the buffers incase fail
            cin.clear();
            cin.ignore(100,'\n');
            cls();
            logo();
            staff_menu.tabulate();
            SetConsoleTextAttribute(color, 4);
            cout << "Error! Enter Valid Numbers Only." << endl;
            SetConsoleTextAttribute(color, 15);
        }else{
            //if cin buffer no error then check if number within valid range
            if(input < 1 || input > 2){
                cls();
                logo();
                staff_menu.tabulate();
                SetConsoleTextAttribute(color, 4);
                cout << "Error! Enter Valid Numbers Only." << endl;
                SetConsoleTextAttribute(color, 15);
            }else{
                break;
            }
        }
    }

    switch(input){
        case 1:
            staffLogin();
        case 2:
            return;
    }
}

